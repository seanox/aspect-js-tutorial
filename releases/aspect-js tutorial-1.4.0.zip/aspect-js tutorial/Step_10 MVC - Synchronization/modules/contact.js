window["contact"] = {
    name: null,
    email: null,
    subject: null,
    comment: null
}